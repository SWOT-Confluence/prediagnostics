#' Write FLPE diagnostics data to file
#'
#' @param diagnostic_data TBD
write_data_flpe <- function(diagnostic_data) {
  ## Will need to write diagnostic data to file; should it be appended to 
  ## FLPE output? Or tracked in the SoS?
}

#' Write Integrator diagnostics data to file
#'
#' @param diagnostic_data TBD
write_data_integrator <- function(diagnostic_data) {
  ## Will need to write diagnostic data to file; should it be appended to 
  ## Integrator output? Or tracked in the SoS?
}