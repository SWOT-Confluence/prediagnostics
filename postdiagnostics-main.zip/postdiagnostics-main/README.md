# postdiagnostics

postdiagnostics serves as a diagnostic module for Confluence. It parses FLPE and integrator data and compares priors and posteriors on discharge. This module outputs data ?.

TO DO:
- Implement integrator functions in all files after integrator output is better understood
- Implement run_diagnostics method in "process.R" file
- Implement write_data in "output.R" file

# installation

# setup

# execution